import os
import subprocess

# YouTube Stream Key
stream_key = os.environ.get("STREAM_KEY")  # secure method

# FFmpeg command to stream in 360p non-stop loop
command = [
    'ffmpeg',
    '-re',
    '-stream_loop', '-1',
    '-i', 'video.mp4',
    '-vcodec', 'libx264',
    '-preset', 'veryfast',
    '-b:v', '400k',
    '-maxrate', '500k',
    '-bufsize', '1000k',
    '-vf', 'scale=640:360',
    '-acodec', 'aac',
    '-b:a', '128k',
    '-ar', '44100',
    '-f', 'flv',
    f'rtmp://a.rtmp.youtube.com/live2/{{stream_key}}'
]

subprocess.run(command)
